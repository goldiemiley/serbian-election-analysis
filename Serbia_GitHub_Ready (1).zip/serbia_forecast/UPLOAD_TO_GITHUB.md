# Upload this project to a private GitHub repository

You can do this in your browser. No terminal, password sharing, or access token is needed.

## 1. Download and extract

Download `Serbia_GitHub_Ready.zip` from the accompanying answer. On Windows, right-click it and select **Extract All**. On macOS, double-click it. Open the extracted **serbia_forecast** folder. It contains `README.md`, the two STEP notebooks, and the project folders.

Use the contents of this cleaned folder for the upload. The original ZIPs and cloud-console screenshots are outside its privacy review.

## 2. Protect your commit email

Sign in to GitHub. Open [Settings → Emails](https://github.com/settings/emails). Enable **Keep my email addresses private**. Also enable **Block command line pushes that expose my email** if that option is available. Web commits then use GitHub's no-reply address. This protects the email address, while your GitHub account remains associated with the commits.

## 3. Create a private repository

Open [the prefilled new-repository page](https://github.com/new?name=serbia-election-forecast&visibility=private).

1. Check the owner is your intended account.
2. Use `serbia-election-forecast` as the name, or choose another name if it is taken.
3. Confirm **Private** is selected.
4. Leave the optional README, .gitignore template, and license selections empty. This package already supplies the first two; no redistribution license has been established.
5. Click **Create repository**.

## 4. Upload the project: batch 1

An empty repository shows an **uploading an existing file** link. Otherwise, use **Add file → Upload files**.

On your computer, open the extracted `serbia_forecast` folder. Select **all its files and folders except `data` and `sample_outputs`**, and drag that selection into GitHub's upload area. This batch has **89 files**, counting files inside folders.

Include `.gitignore` and `.gitattributes`. If they are hidden on macOS, press **Command + Shift + .** to show hidden files; on Linux, use **Ctrl + H**. They are present in the cleaned ZIP.

Check the upload preview: `README.md` should be at the top level, and the module paths should look like `src/pipeline.py`. If everything begins with `serbia_forecast/`, cancel that upload and select the folder's **contents** instead of the outer folder.

Enter the commit message **Add privacy-prepared forecasting project**. Save the upload with the commit button; select **Commit directly to main** if offered for your new repository. If you instead create a branch, finish the pull request and merge it before starting the next batch.

## 5. Upload the electoral data: batch 2

Return to the repository's top-level page. Choose **Add file → Upload files**. Drag the entire **data** folder from inside your extracted `serbia_forecast` folder into the upload area.

This batch has **30 files**. The preview should show paths such as `data/serbia_bigquery/election_totals.csv`. Use **Add electoral CSVs and source schemas** as the commit message and save the upload.

## 6. Upload the saved results: batch 3

At the repository's top-level page, choose **Add file → Upload files** again. Drag the entire **sample_outputs** folder into the upload area.

This batch has **48 files**. The preview should show paths such as `sample_outputs/A_national_votes_shares_seats.csv`. Use **Add archived conditional forecast outputs** as the commit message and save it.

GitHub's browser uploader supports at most **100 files per upload** and **25 MiB per file**. These batches fit those limits; the largest included file is about **14 MiB**. Keeping the folder paths in the preview is essential. Uploading the ZIP as a single repository file would not give you browsable source and data files.

## 7. Check the result

Confirm the repository name has a **Private** badge. Open `README.md`, `STEP2_run_forecast.ipynb`, and `data/serbia_bigquery/source_manifest.csv`. Confirm the folders `src`, `sql`, `config`, `data_to_import`, `data`, and `sample_outputs` are at the repository's top level.

For an optional local privacy check, open a terminal in the extracted folder and run:

```bash
python3 tools/privacy_check.py
```

Use Google Colab separately to run the forecasting notebook; uploading to GitHub does not execute the model or connect GitHub to BigQuery. The root README explains how to enter the cloud identifiers privately. Since the electoral data are already loaded, start with STEP2. STEP1 is an optional loader that replaces tables in the dataset you select.

## Later updates

Keep your executed Colab notebook private. Clear all outputs before uploading a new notebook copy: **Edit → Clear all outputs**, then save/download it. Error messages can contain cloud identifiers. If that menu label changes, use Colab's command search for **clear all outputs**.

Only upload reviewed files. A `.gitignore` does not filter the browser's upload selection. It also does not remove a file that was already committed. The supplied scanner checks common secret formats and saved notebook outputs; it is not a guarantee that future prose, images, or data are free of personal details.

## If the originals are already on GitHub

Start by making that repository private in **Settings → General → Danger Zone → Change repository visibility**, if you control it. Replacing a file with the cleaned version does **not** remove earlier commits or copies already downloaded. A new private repository gives this cleaned copy a fresh history but does not erase the old repository.

Before rewriting or deleting existing history, provide the repository URL for review. Do not share a GitHub password, access token, service-account key, or Google credential file. Private repositories control access; they do not make your account anonymous to collaborators or the service provider.

## Official instructions

- [Create a repository](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)
- [Upload files and browser limits](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
- [Protect your commit email](https://docs.github.com/en/account-and-profile/how-tos/email-preferences/setting-your-commit-email-address)
- [Remove sensitive data from history](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/removing-sensitive-data-from-a-repository)
