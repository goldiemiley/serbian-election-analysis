# Uploaded result snapshot

These files are from the separately uploaded `forecast_outputs.zip`. They replace the older duplicate snapshot embedded in v3. All result CSV bytes are preserved. `run_metadata.json` retains the supplied seed, scenario settings, and Python/library versions; the host OS/kernel fingerprint is removed.

This is an archived conditional run. The outputs were not regenerated or certified by the privacy review. The metadata still contains the uploaded target date, threshold-denominator choice, and minority-uplift choice. Review those settings against the applicable law and verified sources before interpreting the seat and government probabilities. See the root README and `ARCHITECTURE.md`.
